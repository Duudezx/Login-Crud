<!DOCTYPE html>
<html>

<head>
    <?php
    include('header.php');
    ?>
    <title>Consultar Dados</title>
</head>

<body>
    <h1>Consultar Dados</h1>
    <h2>Preencha o formulário abaixo para Consultar o seu cadastro</h2>
    <div id='forms'>
        <?php
        include('paginas/formularios/cadastro/consultar-cadastro.php');
        ?>
    </div>
    <div class="bg">
    </div>
</body>

</html>
<?php
include('footer.php');
?>