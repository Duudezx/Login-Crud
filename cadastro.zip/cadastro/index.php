<?php
    
?>
<!DOCTYPE html>
<html>
<head>
    <?php
        include ('header.php'); 
    ?>
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <h2>Preencha o formulário abaixo para realizar seu login</h2>
    <div id='forms'> 
        <?php
            include ('paginas/formularios/login/login.php'); 
        ?>
    </div>
</body>
</html>
<?php
        include ('footer.php'); 
?>