<!DOCTYPE html>
<html>

<head>
    <?php
    include('header.php');
    ?>
    <title>Apagar Dados</title>
</head>

<body>
    <h1>Apagar Dados</h1>
    <h2>Preencha o formulário abaixo para Apagar o seu cadastro</h2>
    <div id='forms'>
        <?php
        include('paginas/formularios/cadastro/apagar-cadastro.php');
        ?>
    </div>
    <div class="bg">
    </div>
</body>

</html>
<?php
include('footer.php');
?>