<?php
$driver = 'mysql';                  //Qual driver de banco de dados iremos utilizar;
$server = 'localhost';              //Qual nome ou ip do servidor de banco de dados;
$database = 'db_usuario';           //Qual o nome da base de dados ;
$user = 'root';                     //Qual o nome do usuário de acesso ao servidor de banco de dados e da base de dados;
$password = 'root';                 //Qual a senha do usuário ao servidor;
?>