<?php
require_once('connection-config.php');

include('conexao-pdo.php');

?>