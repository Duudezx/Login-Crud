<p>
    <a class='btna' href='http://localhost:8080/paginas/formularios/cadastro/apagar-cadastro'> Apagar Registro </a>
    <a class='btna' href='http://localhost:8080/paginas/formularios/cadastro/atualizar-cadastro'> Alterar Informações </a>
    <a class='btna' href='http://localhost:8080/cadastro/paginas/formularios/cadastro/consultar-cadastro'> Consultar Informações </a>
</p>