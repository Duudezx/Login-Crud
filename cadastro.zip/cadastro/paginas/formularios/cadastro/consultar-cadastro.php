<form action='' method='POST' name='consultar-cadastro' id='consultar-cadastro'>    
    <p>
        cpf: 
            <input type='text' id='txtcpf' name='txtcpf' placeholder='CPF' autofocus/>
    </p>
    <p> 
        <button type='reset' name='btnlimpar' class="btn">Limpar</button>
        <button name='btconsultar' class="btn"> Consultar </button >
            <p>
                <a class='btna' href='http://localhost:8080/cadastro/index-login.php'> Home </a>
            </p>
        <input type="hidden" name='hdncontrole' value='tabajara-never-ends'>
    </p>
</form>